<?php
return array (
  'app_version' => 'v6.1.0',
  'full_app_version' => 'v6.1.0 - build 10161-ga8ca3ad2a',
  'build_version' => '10161',
  'prerelease_version' => '',
  'hash_version' => 'ga8ca3ad2a',
  'full_hash' => 'v6.1.0-127-ga8ca3ad2a',
  'branch' => 'master',
);
